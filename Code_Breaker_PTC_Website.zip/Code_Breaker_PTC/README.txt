CODE BREAKER — PATEROS TECHNOLOGICAL COLLEGE
============================================

HOW TO OPEN
1. Extract Code_Breaker_PTC_Website.zip.
2. Open the extracted folder.
3. Double-click index.html. It will open in your browser.
4. On a phone, upload/publish the entire folder to a static web host, then open its public link.

MOBILE SUPPORT
The website layout is responsive and adapts to phones, tablets, and computers.
It includes a basic PWA manifest and service worker. After hosting over HTTPS,
some browsers can offer "Add to Home Screen" / "Install App".

IMPORTANT LIMITATIONS
- Student ID is collected as a demo label only. This prototype does NOT verify
  real enrollment or year level against PTC records.
- Do not use real student records until an authorized school database/API and
  appropriate privacy/security controls are connected.
- The programming puzzles are learning simulations in this front-end prototype;
  the sample editor checks a specific expected solution and is not a full Python
  interpreter.
- The QR section is a placeholder until the website has a permanent public URL.
  After publishing, generate a QR code from that exact URL.

FILES
index.html       Main website
style.css        Green responsive design
script.js        Navigation, demo access, puzzle logic
manifest.json    Add-to-home-screen metadata
sw.js            Basic offline cache
assets/          PTC campus photo and logo

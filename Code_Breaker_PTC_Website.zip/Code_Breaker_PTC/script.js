const $=id=>document.getElementById(id);
const modal=$('loginModal'), nav=$('mainNav');
function openLogin(year=''){modal.classList.remove('hidden');$('loginMessage').textContent='';$('loginMessage').className='login-message';if(year)$('yearLevel').value=year;}
function closeLogin(){modal.classList.add('hidden')}
$('startBtn').onclick=()=>openLogin();
$('navLogin').onclick=()=>openLogin();
$('closeModal').onclick=closeLogin;
modal.addEventListener('click',e=>{if(e.target===modal)closeLogin()});
$('menuToggle').onclick=()=>{nav.classList.toggle('open');$('menuToggle').setAttribute('aria-expanded',nav.classList.contains('open'))};
nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));
document.querySelectorAll('[data-year]').forEach(b=>b.onclick=()=>openLogin(b.dataset.year));
$('progressBtn').onclick=()=>alert('Log in to view your learning progress and achievements.');
$('hintBtn').onclick=()=>{$('outputText').textContent='Hint: Check the opening and closing parentheses in the print() statement.'};
$('runCode').onclick=()=>{
 const code=$('codeInput').value.trim();
 if(code.includes('print("Hello, PTC!")')||code.includes("print('Hello, PTC!')")) $('outputText').textContent='Hello, PTC!\\n\\n✓ Correct! You fixed the syntax error. +50 XP';
 else $('outputText').textContent='SyntaxError: Check your quotation marks and parentheses.\\n\\nHint: print("your message") needs an opening and closing parenthesis.';
};
const paths={
 '1':[
  {title:'LEVEL 01 — VARIABLES',type:'COMPLETE THE CODE',prompt:'What value will be printed by this program?',code:'x = 4\\ny = 3\\nprint(x + y)',answer:['7'],hint:'The plus sign adds the two values.',explain:'4 + 3 = 7. Variables store values that can be used in calculations.'},
  {title:'LEVEL 02 — DATA TYPES',type:'IDENTIFY THE TYPE',prompt:'What data type is the value "Hello, PTC"?',code:'school = "Hello, PTC"\\nprint(type(school))',answer:['string','str'],hint:'Text surrounded by quotation marks is a string.',explain:'A string (str) is a data type used for text.'},
  {title:'LEVEL 03 — CONDITIONS',type:'PREDICT THE OUTPUT',prompt:'What will this code display?',code:'score = 85\\nif score >= 75:\\n    print("Passed")\\nelse:\\n    print("Try again")',answer:['passed'],hint:'85 is greater than or equal to 75.',explain:'The condition is true, so the program displays Passed.'}
 ],
 '2':[
  {title:'LEVEL 01 — DEBUGGING',type:'FIND THE LOGIC ERROR',prompt:'What should replace the question mark to calculate the sum?',code:'numbers = [2, 4, 6, 8]\\ntotal = 0\\nfor number in numbers:\\n    total = total ? number\\nprint(total)',answer:['+'],hint:'You need to add each number to the running total.',explain:'Use + so each loop adds the next number. The final total is 20.'},
  {title:'LEVEL 02 — FUNCTIONS',type:'COMPLETE THE FUNCTION',prompt:'What keyword sends a result back from a function?',code:'def multiply(a, b):\\n    ______ a * b\\n\\nprint(multiply(4, 3))',answer:['return'],hint:'This keyword gives the calculated value back to the caller.',explain:'return sends a value from a function back to the code that called it.'},
  {title:'LEVEL 03 — LISTS',type:'SOLVE THE PROBLEM',prompt:'What is the index of the first item in a Python list?',code:'colors = ["green", "blue", "white"]\\nprint(colors[0])',answer:['0','zero'],hint:'Python list positions start counting at zero.',explain:'The first item is at index 0, so colors[0] is green.'}
 ]};
let currentYear='1',currentIndex=0,xp=0,student='';
function showChallenge(){const c=paths[currentYear][currentIndex];$('challengeTitle').textContent=c.title;$('challengeType').textContent=c.type;$('challengePrompt').textContent=c.prompt;$('challengeCode').textContent=c.code;$('challengePoints').textContent='+50 XP';$('answerInput').value='';$('challengeFeedback').textContent='';$('nextChallenge').classList.add('hidden');$('submitAnswer').disabled=false;$('submitAnswer').textContent='SUBMIT ANSWER';}
$('loginForm').onsubmit=e=>{
 e.preventDefault();student=$('studentId').value.trim();currentYear=$('yearLevel').value;
 if(!student){$('loginMessage').textContent='Please enter your student ID.';return;}
 if(currentYear!=='1'&&currentYear!=='2'){$('loginMessage').textContent='This game currently has learning paths for First Year and Second Year students only.';return;}
 closeLogin();$('gameScreen').classList.remove('hidden');document.querySelector('main').classList.add('hidden');document.querySelector('footer').classList.add('hidden');
 $('gameYearLabel').textContent=currentYear==='1'?'FIRST YEAR • BEGINNER PATH':'SECOND YEAR • INTERMEDIATE PATH';$('studentLabel').textContent=student;currentIndex=0;xp=0;updateXP();showChallenge();window.scrollTo(0,0);
};
function updateXP(){$('xpValue').textContent=xp+' XP';$('xpBar').style.width=Math.min(100,xp/150*100)+'%';}
$('gameHint').onclick=()=>{$('challengeFeedback').textContent='💡 '+paths[currentYear][currentIndex].hint};
$('submitAnswer').onclick=()=>{
 const c=paths[currentYear][currentIndex],ans=$('answerInput').value.trim().toLowerCase();
 if(c.answer.includes(ans)){xp+=50;updateXP();$('challengeFeedback').textContent='✓ Correct! '+c.explain+' +50 XP';$('challengeFeedback').style.color='#39ff91';$('submitAnswer').disabled=true;$('nextChallenge').classList.remove('hidden');}
 else{$('challengeFeedback').textContent='Not quite. Try again! Read the hint and review the code.';$('challengeFeedback').style.color='#ffb4b4';}
};
$('nextChallenge').onclick=()=>{currentIndex=(currentIndex+1)%paths[currentYear].length;showChallenge();};
function exitGame(){ $('gameScreen').classList.add('hidden');document.querySelector('main').classList.remove('hidden');document.querySelector('footer').classList.remove('hidden');closeLogin();window.scrollTo(0,0);}
$('backHome').onclick=exitGame;$('exitGame').onclick=exitGame;
if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('sw.js').catch(()=>{});
